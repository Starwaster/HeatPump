HeatPump from RealFuels, updated for KSP 1.0.4

The purpose of Heat Pump is to cool down cryogenic tanks and prevent (or retard) boiloff.
Pumps can be configured with the following features.
* An amount of heat is removed from protected parts (active refrigeration) equal to a flat rate multiplied by a temperature delta.
* The flat rate is capped at twice its value times the number of radiators placed symmetrically.
* An additional amount equal to the amount of heat conducting from adjacent parts and from the skin.
* Resource cost per kilowatt of heat removed. 

Currently, the only part is the zzz radiator (licensed by GingerCorp)
